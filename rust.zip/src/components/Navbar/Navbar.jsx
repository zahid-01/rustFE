import React, { useEffect, useRef, useState } from "react";
import "./Navbar.css"
// import './Navbar/Navbar.css'
import { useGSAP } from "@gsap/react";
import { Link } from "react-router-dom";
import gsap from "gsap";


const Navbar = () => {
    const [activeTab, setActiveTab] = useState('navHome')
    const navContainer = useRef();
    const spanRef = useRef();

    const { contextSafe } = useGSAP({ scope: navContainer });

    useGSAP(() => {
        const location = document.getElementById('navHome').getBoundingClientRect();
        const tl = gsap.timeline();
        tl.from(".nav-links", {
            opacity: 0,
            delay: 0.3,
            duration: 0.7,
            y: -60,
            stagger: 0.2,
            borderRadius: 20,
        });

        gsap.from(".nav-logo", {
            opacity: 0,
            delay: 0.5,
            duration: 0.5,
            x: -50,
            stagger: 0.1,
            ease: "elastic.out(1,0.5)",
        });

        gsap.from(".nav-signIn", {
            opacity: 0,
            delay: 0.5,
            duration: 0.5,
            x: 50,
            stagger: 0.1,
            ease: "elastic.out(1,0.5)",
        });

        gsap.to(spanRef.current, {
            opacity: 1,
            duration: 0.7,
            top: location.top - 20,
            bottom: location.bottom,
            right: location.right,
            left: location.left - 6,
            // scale: 0,
            transformOrigin: "center",
        });
    });

    const handleLinkClick = contextSafe((className) => {
        setActiveTab(className);
        console.log(className);
        const location = document.getElementById(className).getBoundingClientRect();
        console.log(location)
        gsap.to(spanRef.current, {
            opacity: 1,
            // x:location.x - 39,
            // y:location.y - 18,
            duration: 0.3,
            // ease: "bounce.out(0.5,0.1)",
            width: location.width + 7,
            top: location.top - 20,
            bottom: location.bottom,
            right: location.right,
            left: location.left - 4,
            // transformOrigin: "center",
            // ease: "elastic.out(1,0.5)",

        });
    });

    return (
        <nav className="h-14 text-white overflow-hidden relative justify-between pl-9 pr-9 items-center flex theme-white-app box-shadow-app">
            <div className="nav-logo cursor-pointer overflow-hidden h-[50%]">
                <h2 className="text-black-app text-xl font-bold">
                    Coin Flip
                </h2>
                <h2 className="text-black-app text-xl font-bold ">Coin Flip</h2>
            </div>

            <span ref={spanRef} className={`h-[180%] left-[-70%] absolute theme-grey-app w-14 rotate-6`}>

            </span>
            <div className="flex overflow-hidden h-100 gap-9 items-center justify-evenly w-96 relative">
                <span id="navHome" className="h-100 flex items-center">
                    <Link>
                        <h5


                            className={`nav-links font-semibold ${activeTab === "navHome" ? "text-white" : "text-black-app"} cursor-pointer`}
                            onClick={() => handleLinkClick("navHome")}
                        >
                            Home
                        </h5></Link>

                </span>

                <span id="navPlay" className="h-100 flex items-center">
                    <Link to='/play'>
                        <h5


                            className={`nav-links font-semibold ${activeTab === "navPlay" ? "text-white" : "text-black-app"} cursor-pointer`}
                            onClick={() => handleLinkClick("navPlay")}
                        >
                            Play
                        </h5></Link>

                </span>


                <span id="navFAQ" className="h-100 flex items-center">
                    <h5
                        className={`nav-links font-semibold ${activeTab === "navFAQ" ? "text-white" : "text-black-app"} cursor-pointer`}
                        onClick={() => handleLinkClick("navFAQ")}
                    >
                        FAQ
                    </h5>
                </span>
                <span id="navSupport" className="h-100 flex items-center">
                    <h5

                        className={`nav-links font-semibold ${activeTab === "navSupport" ? "text-white" : "text-black-app"} cursor-pointer`}
                        onClick={() => handleLinkClick("navSupport")}
                    >
                        Support
                    </h5>
                </span>
            </div>
            <div
                ref={navContainer}
                className="nav-signIn button-grey-gradient pl-4 pr-4 pt-2 pb-2 flex items-center justify-center cursor-pointer"
            >
                <p>Sign in</p>
            </div>
        </nav>
    );
};

export default Navbar;