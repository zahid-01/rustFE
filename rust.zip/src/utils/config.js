const BASE_URI = "http://localhost:5001/api/v1";

export default BASE_URI;
